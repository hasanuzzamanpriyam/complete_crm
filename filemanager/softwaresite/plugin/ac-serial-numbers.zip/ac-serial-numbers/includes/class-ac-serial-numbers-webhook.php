<?php

class AC_Serial_Numbers_Webhook {

    private static $instance;

    public static function init() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof AC_Serial_Numbers_Webhook ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

    public function __construct() {
        add_action('rest_api_init', function () {
            register_rest_route('ac-serial-numbers/v1', '/webhook/', [
                'methods'  => 'POST',
                'callback' => array($this, 'webhook_handler'),
                'permission_callback' => function ($request) {
                    $secret_key = get_option('_ac_serial_numbers_webhook_secret'); // Retrieve stored key
                    $provided_key = $request->get_header('X-Webhook-Secret'); // Get key from request
                    return $provided_key === $secret_key; // Validate key
                }
            ]);
        });
    }

    public function webhook_handler(WP_REST_Request $request) {
        global $wpdb;
        $system_activation_guide = get_option('ac_serial_numbers_system_activation_guide') ?? false;
        $logger = wc_get_logger();
	    $context = ['source' => 'wcsn-webhook'];
        $data = $request->get_json_params();
        if (empty($data)) {
            $logger->error('Invalid Data', $context);
            return new WP_REST_Response(['message' => 'Invalid Data'], 400);
        }
        $order_id = $data['invoice_no'] ?? 0;

        if (!$order_id) {
            $logger->error('Order ID is required', $context);
            $logger->error(print_r($data, true), $context);
            return new WP_REST_Response(['message' => 'Order ID is required'], 400);
        }

        $order = wc_get_order($order_id);

        if (!$order) {
            $logger->error('Order not found', $context);
            $logger->error(print_r($data, true), $context);
            return new WP_REST_Response(['message' => 'Order not found'], 404);
        }

        // first Serial number insert in order
        if (isset($data['orderData']) && is_array($data['orderData'])) {
            // first loop on each order_items
            foreach ($data['orderData'] as $order_item ) { // $data['orderData'] is an array of order items
                if(is_array($order_item['serialKeys']) && count($order_item['serialKeys']) > 0){
					
					$keys = isset($order_item['serialKeys']) ? $order_item['serialKeys'] : [];
					
					foreach ($keys as $key) {
						$wpdb->insert(
							$wpdb->prefix . 'serial_numbers',
							array(
								'serial_key' => $key['serialNumber'] . ' | ' .($system_activation_guide ?? $key['activationGuide']) ?? '',
								'product_id' => $order_item['cp_id'],
								'activation_limit' => $key['activation_limit'] ?? 1,
								'activation_count' => 0,
								'order_id'   => $order_id,
								'vendor_id' => $key['supplierId'] ?? '',
								'status' => 'sold',
								'validity' => null,						
								'order_date' => $key['createdAt'],
								'source' => 'reseller',
								'created_date' => $key['createdAt'],
							)
						);
					}
				}
            }
            
        }

        // Update order status to "completed"
        $order->update_status('completed', 'Order updated via TIC KeyManager Webhook');

        $logger->info('Order status updated to completed', $context);
        $logger->info(print_r($data, true), $context);

        return new WP_REST_Response(['message' => 'Order status updated to completed'], 200);
    }

    // private function __construct() {
	// 	$this->define_constants();
	// 	register_activation_hook( __FILE__, array( $this, 'activate_plugin' ) );
	// 	register_deactivation_hook( __FILE__, array( $this, 'deactivate_plugin' ) );

	// 	add_action( 'woocommerce_loaded', array( $this, 'init_plugin' ) );
	// 	add_action( 'admin_notices', array( $this, 'wc_missing_notice' ) );
	// 	add_filter('site_transient_update_plugins', array( $this , 'remove_update_notification' ) );
	// }


}

AC_Serial_Numbers_Webhook::init();