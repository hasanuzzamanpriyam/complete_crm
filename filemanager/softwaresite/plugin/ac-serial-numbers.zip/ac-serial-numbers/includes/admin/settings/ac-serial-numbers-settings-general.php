<?php
defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'AC_Serial_Numbers_Settings_General' ) ) :
	/**
	 * AC_Serial_Numbers_Settings_General
	 */
	class AC_Serial_Numbers_Settings_General extends WC_Settings_Page {
		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->id    = 'general';
			$this->label = __( 'General', 'ac-serial-numbers' );

			add_filter( 'ac_serial_numbers_settings_tabs_array', array( $this, 'add_settings_page' ), 20 );
			add_action( 'ac_serial_numbers_settings_' . $this->id, array( $this, 'output' ) );
			add_action( 'ac_serial_numbers_settings_save_' . $this->id, array( $this, 'save' ) );
		}

		/**
		 * Get settings array
		 *
		 * @return array
		 */
		public function get_settings() {
			global $woocommerce, $wp_roles;
			$settings = array(
				[
					'title' => __( 'Serial Number Settings.', 'ac-serial-numbers' ),
					'type'  => 'title',
					'desc'  => __( 'The following options affects how the serial numbers will work.', 'ac-serial-numbers' ),
					'id'    => 'section_serial_numbers'
				],
				[
					'title'   => __( 'Auto Complete Order', 'ac-serial-numbers' ),
					'id'      => 'ac_serial_numbers_autocomplete_order',
					'desc'    => __( 'This will automatically complete an order after successfull payment.', 'ac-serial-numbers' ),
					'type'    => 'checkbox',
					'default' => 'no',
				],
				[
					'title' => __( 'Reuse Serial Number', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_reuse_serial_number',
					'desc'  => __( 'This will recover failed, refunded serial number for selling again.', 'ac-serial-numbers' ),
					'type'  => 'checkbox',
				],
				[
					'title'           => __( 'Revoke statuses', 'ac-serial-numbers' ),
					'desc'            => __( 'Cancelled', 'ac-serial-numbers' ),
					'id'              => 'ac_serial_numbers_revoke_status_cancelled',
					'default'         => 'yes',
					'type'            => 'checkbox',
					'checkboxgroup'   => 'start',
					'show_if_checked' => 'option',
				],
				[
					'desc'          => __( 'Refunded', 'ac-serial-numbers' ),
					'id'            => 'ac_serial_numbers_revoke_status_refunded',
					'default'       => 'yes',
					'type'          => 'checkbox',
					'checkboxgroup' => '',

				],
				[
					'desc'          => __( 'Failed', 'ac-serial-numbers' ),
					'id'            => 'ac_serial_numbers_revoke_status_failed',
					'default'       => 'yes',
					'type'          => 'checkbox',
					'checkboxgroup' => 'end',

				],
				[
					'title'   => __( 'Hide Serial Number', 'ac-serial-numbers' ),
					'id'      => 'ac_serial_numbers_hide_serial_number',
					'desc'    => __( 'All serial numbers will be hidden and only displayed when the "Show" button is clicked.', 'ac-serial-numbers' ),
					'default' => 'yes',
					'type'    => 'checkbox',
				],
				[
					'title'   => __( 'Disable Software Support', 'ac-serial-numbers' ),
					'id'      => 'ac_serial_numbers_disable_software_support',
					'desc'    => __( 'This will disable Software Licensing support & API functionalities..', 'ac-serial-numbers' ),
					'default' => 'yes',
					'type'    => 'checkbox',
				],
				[
					'type' => 'sectionend',
					'id'   => 'section_serial_numbers'
				],
				[
					'title' => __( 'Stock notification.', 'ac-serial-numbers' ),
					'type'  => 'title',
					'desc'  => __( 'The following options affects how stock notification will work.', 'ac-serial-numbers' ),
					'id'    => 'stock_section'
				],
				[
					'title'             => __( 'Stock Notification Email', 'ac-serial-numbers' ),
					'id'                => 'ac_serial_numbers_enable_stock_notification',
					'desc'              => __( 'This will send you notification email when product stock is low.', 'ac-serial-numbers' ),
					'type'              => 'checkbox',
					'sanitize_callback' => 'intval',
				],
				array(
					'title'   => __( 'Stock Threshold', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_stock_threshold',
					'desc'    => __( 'When stock goes below the above number, it will send notification email.', 'ac-serial-numbers' ),
					'type'    => 'number',
					'default' => '5',
				),
				array(
					'title'   => __( 'Notification Recipient Email', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_notification_recipient',
					'desc'    => __( 'The email address to be used for sending the email notification.', 'ac-serial-numbers' ),
					'type'    => 'text',
					'default' => get_option( 'admin_email' ),
				),
				array(
					'title'   => __( 'Serial Number Support Email', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_support_email',
					'desc'    => __( 'The email address to be used for support email in serial number.', 'ac-serial-numbers' ),
					'type'    => 'text',
					'default' => get_option( 'admin_email' ),
				),
				array(
					'title'   => __( 'Activation Guideline', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_system_activation_guide',
					'desc'    => __( 'This text will be sent to your customer along with serial key as activation guide.', 'ac-serial-numbers' ),
					'type'    => 'textarea',
				),
				[
					'type' => 'sectionend',
					'id'   => 'stock_section'
				],
				[
					'title' => __( 'API Settings', 'ac-serial-numbers' ),
					'type'  => 'title',
					'desc'  => __( 'Update API Key to deliver serial number from TIC Keys.', 'ac-serial-numbers' ),
					'id'    => 'api_key_section'
				],
				array(
					'title'   => __( 'API Endpoint', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_api_endpoint',
					'desc'    => __( 'Get your endpoint from TIC Keys.', 'ac-serial-numbers' ),
					'type'    => 'url',
					'placeholder' => 'Paste your API Endpoint here'

				),
				array(
					'title'   => __( 'API Key', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_api_key',
					'desc'    => __( 'Get your key from TIC Keys.', 'ac-serial-numbers' ),
					'type'    => 'text',
					'placeholder' => 'Paste your API key here'

				),
				array(
					'title'   => __( 'Auth Secret', 'ac-serial-numbers' ),
					'id'    => 'ac_serial_numbers_webhook_secret',
					'type'    => 'info',
					'text' => get_option( '_ac_serial_numbers_webhook_secret', '' ),

				),
				[
					'type' => 'sectionend',
					'id'   => 'api_key_section'
				],
			);

			return apply_filters( 'ac_serial_numbers_general_settings_fields', $settings );
		}

		/**
		 * Save settings
		 */
		public function save() {
			$settings = $this->get_settings();
			AC_Serial_Numbers_Admin_Settings::save_fields( $settings );
		}
	}

endif;

return new AC_Serial_Numbers_Settings_General();
