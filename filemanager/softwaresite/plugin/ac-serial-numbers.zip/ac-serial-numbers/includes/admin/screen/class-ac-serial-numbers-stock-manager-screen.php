<?php
defined( 'ABSPATH' ) || exit();

class AC_Serial_Numbers_Admin_Stock_Manager_Screen {
	/**
	 * Render serial number page.
	 *
	 * @since 1.2.0
	 */
	public static function output() {
    ?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php _e( 'Stock Manager', 'ac-serial-numbers' ); ?></h1>
			<hr class="wp-header-end">
      <?php
      if (defined('AC_SERIAL_NUMBERS_SERVER_STATUS')){

        if (AC_SERIAL_NUMBERS_SERVER_STATUS == 101) {
          ?>
          <div class="alert alert-danger">
            <p class="text-danger text-center mb-0">API Endpoint or Key is missing. Check your settings.</p>
          </div>
          <?php
        }else
        if (AC_SERIAL_NUMBERS_SERVER_STATUS == 102) {
          ?>
          <div class="alert alert-danger">
            <p class="text-danger text-center mb-0">Error fetching product data, Couldn't connect to key server.</p>
          </div>
          <?php
        }else
        if (AC_SERIAL_NUMBERS_SERVER_STATUS == 103) {
          ?>
          <div class="alert alert-danger">
            <p class="text-danger text-center mb-0">HTTP Error: Maybe key server is down, check server logs.</p>
          </div>
          <?php
        }else
        if (AC_SERIAL_NUMBERS_SERVER_STATUS == 104) {
          ?>
          <div class="alert alert-danger">
            <p class="text-danger text-center mb-0">Error decoding JSON</p>
          </div>
          <?php
        }else
        if (AC_SERIAL_NUMBERS_SERVER_STATUS == 105) {
          ?>
          <div class="alert alert-danger">
            <p class="text-danger text-center mb-0">No product data was retrieved from the API.</p>
          </div>
          <?php
        }
      }
      ?>
			<table id="ac_serial_numbers_stock_manager" class="table table-striped table-bordered" style="width:100%">
        <thead>
          <tr>
            <th scope="col">Product Name</th>
            <th scope="col">Remote Products</th>
            <th scope="col">Source</th>
            <th scope="col">Available</th>
            <th scope="col">Sold</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $args = array(
              'post_type'      => 'product',
              'posts_per_page' => -1,
              'order' => 'ASC',
            );
            $loop = new WP_Query( $args );
            while ( $loop->have_posts() ) : $loop->the_post();
              global $product;
              $id = $product->get_id();
              global $wpdb;
              $wpdb_prefix = $wpdb->prefix;
              $wpdb_tablename = $wpdb_prefix.'serial_numbers';
              $available =count( $wpdb->get_results("SELECT * FROM $wpdb_tablename WHERE product_id='$id' AND status='available'"));
              $sold =count( $wpdb->get_results("SELECT * FROM $wpdb_tablename WHERE product_id='$id' AND status='sold'"));
              
              $wcsnsc_stock_status="text-dark";
              if($available==0){
                  $wcsnsc_stock_status="text-danger";
              }elseif($available<2){
                  $wcsnsc_stock_status="text-warning";
              }
              $key_source_type = get_post_meta( $id, '_ac_serial_numbers_key_source', true );
              if ($key_source_type == 'reseller'){
                $wcsnsc_stock_status="text-success";
              }
              $plink  = add_query_arg( [
                'product_id' => $id,
                'page'   => 'ac-serial-numbers'
              ], admin_url( 'admin.php' ) );

              $remote_product_title = get_post_meta($id, '_ac_remote_product_title', true);
              $remote_product_id = get_post_meta($id, '_ac_remote_product_id', true);
              ?>
              <tr data-product_id="<?php echo $id; ?>">
                <td>
                  <div class="d-flex justify-content-between align-items-center">
                    <a class="<?php echo $wcsnsc_stock_status; ?>" href="<?php echo $plink; ?>"><?php echo get_the_title(); ?></a>
                  </div>
                </td>
                <td>
                <select name="productsLista" id=""
                      class="regular-text ac-serial-numbers-map-product" required="required"
                      placeholder="<?php _e( 'Select Product', 'ac-serial-numbers' ); ?>">
                      <?php if($remote_product_id && $remote_product_title){?>
                        <option value="<?php echo esc_attr($remote_product_id); ?>"><?php echo esc_attr($remote_product_title); ?></option>
                      <?php }else{ ?>
                        <option value="">Select a Product</option>
                      <?php } ?>

                    </select>
                </td>
                <td class="text-center font-weight-bold">
                  <select name="keysource" class="keysource">
                      <option value="system" <?php echo selected( 'system', $key_source_type ); ?>>System</option>
                      <option value="reseller" <?php echo selected( 'reseller', $key_source_type ); ?>>Reseller</option>
                  </select>
                </td>
                <td class="text-center font-weight-bold"><?php echo $available; ?></td>
                <td class="text-center font-weight-bold"><?php echo $sold; ?></td>
              </tr>
              <?php   
            endwhile;
            wp_reset_query();
          ?>
        </tbody>
      </table>
		</div>
		<?php
	}



}
