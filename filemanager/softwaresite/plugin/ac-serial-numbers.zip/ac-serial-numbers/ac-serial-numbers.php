<?php
/**
 * Plugin Name: AAA Serial Numbers
 * Plugin URI:  https://tic.com.bd/plugins/wocommerce-serial-key-manager-pro/
 * Description: The best WooCommerce Plugin to sell license keys, redeem cards and other secret numbers!
 * Version:     1.0.6
 * Author:      autocircle
 * Author URI:  https://profiles.wordpress.org/autocircle/
 * Donate link: https://profiles.wordpress.org/autocircle/
 * License:     GPLv2+
 * Text Domain: ac-serial-numbers
 * Domain Path: /i18n/languages/
 * Tested up to: 5.8.2
 * WC requires at least: 3.0.0
 * WC tested up to: 6.0.0
 */

/**
 * Copyright (c) 2019 autocircled (email : support@tic.com.bd)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2 or, at
 * your discretion, any later version, as published by the Free
 * Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

// don't call the file directly
defined( 'ABSPATH' ) || exit();

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

define( 'AC_SERIAL_NUMBER_REMOTE_TRANSIENT', 'ac_product_data_transient');
/**
 * AC_Serial_Numbers class.
 *
 * @class AC_Serial_Numbers contains everything for the plugin.
 */
class AC_Serial_Numbers {
	/**
	 * AC_Serial_Numbers version.
	 *
	 * @var string
	 * @since 1.0.0
	 */
	public $version = '1.0.6';

	/**
	 * This plugin's instance
	 *
	 * @var AC_Serial_Numbers The one true AC_Serial_Numbers
	 * @since 1.0
	 */
	private static $instance;

	/**
	 * Main AC_Serial_Numbers Instance
	 *
	 * Insures that only one instance of AC_Serial_Numbers exists in memory at any one
	 * time. Also prevents needing to define globals all over the place.
	 *
	 * @return AC_Serial_Numbers The one true AC_Serial_Numbers
	 * @since 1.0.0
	 * @static var array $instance
	 */
	public static function init() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof AC_Serial_Numbers ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


	/**
	 * Return plugin version.
	 *
	 * @return string
	 * @since 1.2.0
	 * @access public
	 **/
	public function get_version() {
		return $this->version;
	}

	/**
	 * Plugin URL getter.
	 *
	 * @return string
	 * @since 1.2.0
	 */
	public function plugin_url() {
		return untrailingslashit( plugins_url( '/', __FILE__ ) );
	}

	/**
	 * Plugin path getter.
	 *
	 * @return string
	 * @since 1.2.0
	 */
	public function plugin_path() {
		return untrailingslashit( plugin_dir_path( __FILE__ ) );
	}

	/**
	 * Plugin base path name getter.
	 *
	 * @return string
	 * @since 1.2.0
	 */
	public function plugin_basename() {
		return plugin_basename( __FILE__ );
	}

	/**
	 * Initialize plugin for localization
	 *
	 * @return void
	 * @since 1.0.0
	 *
	 */
	public function localization_setup() {
		load_plugin_textdomain( 'ac-serial-numbers', false, plugin_basename( dirname( __FILE__ ) ) . '/i18n/languages' );
	}

	/**
	 * Determines if the pro version active.
	 *
	 * @return bool
	 * @since 1.0.0
	 *
	 */
	public function is_pro_active() {
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

		return is_plugin_active( 'ac-serial-numbers-pro/ac-serial-numbers-pro.php' ) == true;
	}

	/**
	 * Determines if the wc active.
	 *
	 * @return bool
	 * @since 1.0.0
	 *
	 */
	public function is_wc_active() {
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

		return is_plugin_active( 'woocommerce/woocommerce.php' ) == true;
	}

	/**
	 * WooCommerce plugin dependency notice
	 * @since 1.2.0
	 */
	public function wc_missing_notice() {
		if ( ! $this->is_wc_active() ) {
			$message = sprintf( __( '<strong>TIC Serial Numbers</strong> requires <strong>WooCommerce</strong> installed and activated. Please Install %s WooCommerce. %s', 'ac-serial-numbers' ),
				'<a href="https://wordpress.org/plugins/woocommerce/" target="_blank">', '</a>' );
			echo sprintf( '<div class="notice notice-error"><p>%s</p></div>', $message );
		}
	}

	/**
	 * Define constant if not already defined
	 *
	 * @param string $name
	 * @param string|bool $value
	 *
	 * @return void
	 * @since 1.2.0
	 *
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Throw error on object clone
	 *
	 * The whole idea of the singleton design pattern is that there is a single
	 * object therefore, we don't want the object to be cloned.
	 *
	 * @access protected
	 * @return void
	 */

	public function __clone() {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'ac-serial-numbers' ), '1.0.0' );
	}

	/**
	 * Disable unserializing of the class
	 *
	 * @access protected
	 * @return void
	 */

	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'ac-serial-numbers' ), '1.0.0' );
	}

	/**
	 * AC_Serial_Numbers constructor.
	 */
	private function __construct() {
		$this->define_constants();
		register_activation_hook( __FILE__, array( $this, 'activate_plugin' ) );
		register_deactivation_hook( __FILE__, array( $this, 'deactivate_plugin' ) );

		add_action( 'woocommerce_loaded', array( $this, 'init_plugin' ) );
		add_action( 'admin_notices', array( $this, 'wc_missing_notice' ) );
		add_filter( 'site_transient_update_plugins', array( $this , 'remove_update_notification' ) );
		add_action( 'plugins_loaded', array( $this, 'update_check' ) );
	}
	
	public function remove_update_notification($value) {
         unset($value->response[ plugin_basename(__FILE__) ]);
         return $value;
    } 

	/**
	 * Define all constants
	 * @return void
	 * @since 1.2.0
	 */
	public function define_constants() {
		$this->define( 'AC_SERIAL_NUMBER_PLUGIN_VERSION', $this->version );
		$this->define( 'AC_SERIAL_NUMBER_PLUGIN_FILE', __FILE__ );
		$this->define( 'AC_SERIAL_NUMBER_PLUGIN_DIR', dirname( __FILE__ ) );
		$this->define( 'AC_SERIAL_NUMBER_PLUGIN_INC_DIR', dirname( __FILE__ ) . '/includes' );
	}

	/**
	 * Activate plugin.
	 *
	 * @return void
	 * @since 1.2.0
	 */
	public function activate_plugin() {
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-installer.php';
		AC_Serial_Numbers_Installer::install();
		$this->webhook_secret();
	}

	public function webhook_secret(){
		$data = get_option('_ac_serial_numbers_webhook_secret');
		if($data) return $data;
		$secret_key = wp_generate_password(32, false); // Generate a 32-character secret
    	update_option('_ac_serial_numbers_webhook_secret', $secret_key);
	}

	/**
	 * Deactivate plugin.
	 *
	 * @return void
	 * @since 1.2.0
	 */
	public function deactivate_plugin() {

	}

	/**
	 * Load the plugin when WooCommerce loaded.
	 *
	 * @return void
	 * @since 1.2.0
	 */
	public function init_plugin() {
		$this->includes();
		$this->init_hooks();
	}


	/**
	 * Include required core files used in admin and on the frontend.
	 * @since 1.2.0
	 */
	public function includes() {
		require_once dirname( __FILE__ ) . '/includes/ac-serial-numbers-functions.php';
		require_once dirname( __FILE__ ) . '/includes/ac-serial-numbers-misc-functions.php';
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-query.php';
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-installer.php';
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-order-handler.php';
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-encryption.php';
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-ajax.php';
		// require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-api.php';
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-cron.php';
		// require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-compat.php';
		require_once dirname( __FILE__ ) . '/includes/class-ac-serial-numbers-webhook.php';

		if ( is_admin() ) {
			require_once dirname( __FILE__ ) . '/includes/admin/class-ac-serial-numbers-admin.php';
		}
		do_action( 'ac_serial_numbers__loaded' );
	}


	/**
	 * Hook into actions and filters.
	 *
	 * @since 1.0.0
	 */
	private function init_hooks() {
		add_action( 'plugins_loaded', array( $this, 'localization_setup' ) );
		//add_action( 'plugins_loaded', array( $this, 'on_plugins_loaded' ), - 1 );
	}


	/**
	 * When WP has loaded all plugins, trigger the `ac_serial_numbers__loaded` hook.
	 *
	 * This ensures `ac_serial_numbers__loaded` is called only after all other plugins
	 * are loaded, to avoid issues caused by plugin directory naming changing
	 *
	 * @since 1.0.0
	 */
	public function on_plugins_loaded() {
		do_action( 'ac_serial_numbers__loaded' );
	}

	public function update_check() {
		require_once 'vendor/plugin-update-checker/plugin-update-checker.php';
		PucFactory::buildUpdateChecker(
			'https://repo.tic.com.bd/plugin/ac-serial-numbers.json',
			__FILE__, //Full path to the main plugin file or functions.php.
			'ac-serial-numbers'
		);
	}
}


/**
 * The main function responsible for returning the one true WC Serial Numbers
 * Instance to functions everywhere.
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * @return AC_Serial_Numbers
 * @since 1.2.0
 */
function ac_serial_numbers() {
	return AC_Serial_Numbers::init();
}

//lets go.
ac_serial_numbers();
function sajao( ...$data ) {
	$backtrace = debug_backtrace();

	$backtrace = array_shift( $backtrace );

	$output['backtrace'] = $backtrace['file'] . ':' . $backtrace['line'];
	foreach ( $data as $key => $value ) {
		$output['data' . ($key + 1)] = $value;
	}
	echo '<pre>';
	var_dump($output);
	echo '</pre>';
}
function write_log( ...$data ) {
    if ( true === WP_DEBUG ) {

		$backtrace = debug_backtrace();

		$backtrace = array_shift( $backtrace );

		$output['backtrace'] = $backtrace['file'] . ':' . $backtrace['line'];
		foreach ( $data as $key => $value ) {
            $output['data' . ($key + 1)] = $value;
        }
		error_log( print_r( $output, true ) );
    }
}

function ac_fetch_products_data() {
    $transient_name = AC_SERIAL_NUMBER_REMOTE_TRANSIENT; // Name of your transient
    $transient_timeout = 1 * DAY_IN_SECONDS; // 1 day timeout

    // Check if the transient already exists and is not expired.
    $product_data = get_transient($transient_name);
    if ($product_data === false) {
      $url = 	get_option('ac_serial_numbers_api_endpoint');    
      $api_key = 	get_option('ac_serial_numbers_api_key');

      if (empty($url) || empty($api_key)) {
        error_log("API Endpoint or Key is missing. Check your settings.");
        return 101; // Stop here if URL or API key is missing
      }

      $response = wp_remote_get($url . '/product/all', [
        'headers' => ['api-key' => $api_key,]
      ]);

      if (is_wp_error($response)) {
        error_log("Error fetching product data: " . $response->get_error_message());
        return 102; // Stop on error
      }

      $http_code = wp_remote_retrieve_response_code($response);
      if ($http_code != 200) {
        error_log("HTTP Error: " . $http_code . " - " . wp_remote_retrieve_response_message($response));
        return 103; // Stop on HTTP error
      }

      $data = wp_remote_retrieve_body($response);
      $decoded_data = json_decode($data, true);

      if ($decoded_data === null) {
        error_log("Error decoding JSON: " . json_last_error_msg());
        return 104; // Stop if JSON decoding fails
      }

      if (!empty($decoded_data)) { // Check if data is not empty
        set_transient($transient_name, $decoded_data['products'], $transient_timeout);
        $product_data = $decoded_data['products'];
      } else {
        error_log("No product data was retrieved from the API.");
        return 105;
      }
    }
    return $product_data;
  }